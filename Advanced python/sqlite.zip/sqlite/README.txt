##Author: saudzi

This is a simple python script for working with databases, some simple tables and queries

##usage
since the DB file is included, table and data creation is commented out while running texts in the __main__ section

the few test functions are pretty self explanatory



## License
[MIT](https://choosealicense.com/licenses/mit/)